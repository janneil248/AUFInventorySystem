﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MCOMID1
{
    class settingborrow
    {
        public void data(DataGridView b1)
        {

            b1.ColumnCount = 7;
            b1.Columns[0].Name = "ID";
            b1.Columns[1].Name = "Name";
            b1.Columns[2].Name = "Type";
            b1.Columns[3].Name = "Item";
            b1.Columns[4].Name = "Remarks";
            b1.Columns[5].Name = "UserID";
            b1.Columns[6].Name = "Log";

            b1.Columns["ID"].HeaderText = "ID #";
            b1.Columns["Name"].HeaderText = "Name";
            b1.Columns["Type"].HeaderText = "Type";
            b1.Columns["Item"].HeaderText = "Item Serial";
            b1.Columns["Remarks"].HeaderText = "Remarks";
            b1.Columns["UserID"].HeaderText = "User";
            b1.Columns["Log"].HeaderText = "Log";

            b1.Columns[0].Width = 80;
            b1.Columns[1].Width = 130;
            b1.Columns[2].Width = 60;
            b1.Columns[3].Width = 95;
            b1.Columns[4].Width = 180;
            b1.Columns[5].Width = 35;
            b1.Columns[6].Width = 120;
        }
    }
}
