﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MCOMID1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            SidePanel.Height = btnManage.Height;
            SidePanel.Top = btnManage.Top;
            manage1.BringToFront();

            lbluser.Text = "Hi, User";
         
           
        }
        

        private void BtnManage_Click(object sender, EventArgs e)
        {
            SidePanel.Height = btnManage.Height;
            SidePanel.Top = btnManage.Top;
            manage1.BringToFront();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'appac.datac' table. You can move, or remove it, as needed.
            this.datacTableAdapter.Fill(this.appac.datac);
            // TODO: This line of code loads data into the 'appbr.databr' table. You can move, or remove it, as needed.
            this.databrTableAdapter.Fill(this.appbr.databr);
            // TODO: This line of code loads data into the 'appdata.data' table. You can move, or remove it, as needed.
            this.dataTableAdapter.Fill(this.appdata.data);
            timer1.Start();
            lbldate.Text = DateTime.Now.ToLongDateString();
            lbltime.Text = DateTime.Now.ToLongTimeString();
        }

        private void Timer1_Tick_1(object sender, EventArgs e)
        {
            lbltime.Text = DateTime.Now.ToLongTimeString();
            timer1.Start();
        }

        private void BtnService_Click(object sender, EventArgs e)
        {
            SidePanel.Height = btnService.Height;
            SidePanel.Top = btnService.Top;
            service1.BringToFront();
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Btnchange_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            this.Hide();
            f1.Show();
        }

        private void BtnInventory_Click(object sender, EventArgs e)
        {
            SidePanel.Height = btnInventory.Height;
            SidePanel.Top = btnInventory.Top;
            inventory1.BringToFront();
        }

        private void BtnAccounts_Click(object sender, EventArgs e)
        {
            SidePanel.Height = btnAccounts.Height;
            SidePanel.Top = btnAccounts.Top;
            account1.BringToFront();
        }

        private void DataBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.dataBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.appdata);

        }
    }
}
