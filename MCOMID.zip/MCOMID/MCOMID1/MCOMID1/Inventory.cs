﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MCOMID1
{
    public partial class Inventory : UserControl
    {
      
        

        public Inventory()
        {
            InitializeComponent();
       
        }

        private void Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Inventory_Load(object sender, EventArgs e)
        {
            this.dataTableAdapter.Fill(this.appdata.data);
            this.databrTableAdapter.Fill(this.appbr.databr);
        }

        private void Txtfindserial_TextChanged(object sender, EventArgs e)
        {

        }

        private void DataBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.dataBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.appdata);

        }
    }
}
