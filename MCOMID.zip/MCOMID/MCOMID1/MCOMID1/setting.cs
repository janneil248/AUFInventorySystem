﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MCOMID1
{
    class setting
    {
            public void data(DataGridView m1)
        {
           
            m1.ColumnCount = 7;
            m1.Columns[0].Name = "Serial";
            m1.Columns[1].Name = "Item_Name";
            m1.Columns[2].Name = "Brand";
            m1.Columns[3].Name = "Category";
            m1.Columns[4].Name = "Remarks";
            m1.Columns[5].Name = "UserID";
            m1.Columns[6].Name = "Log";

            m1.Columns["Serial"].HeaderText = "Serial #";
            m1.Columns["Item_Name"].HeaderText = "Item Name";
            m1.Columns["Brand"].HeaderText = "Brand";
            m1.Columns["Category"].HeaderText = "Category";
            m1.Columns["Remarks"].HeaderText= "Remarks";
            m1.Columns["UserID"].HeaderText = "User";
            m1.Columns["Log"].HeaderText = "Log";

            m1.Columns[0].Width = 80;
            m1.Columns[1].Width = 130;
            m1.Columns[2].Width = 80;
            m1.Columns[3].Width = 80;
            m1.Columns[4].Width = 180;
            m1.Columns[5].Width = 35;
            m1.Columns[6].Width = 120;
        }
        public void clr(DataGridView mg1)
        {
            mg1.DataSource = null;
            mg1.Rows.Clear();
            mg1.Columns.Clear();
            mg1.Refresh();

        }
    }
}
