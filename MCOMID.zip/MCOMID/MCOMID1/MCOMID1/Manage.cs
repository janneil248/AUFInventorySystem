﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MCOMID1
{
    public partial class Manage : UserControl
    {
        public Manage()
        {
            InitializeComponent();
            
        }
       
      
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            try
            {

                lbluser.Text = "JP1";
                lbldate.Text = DateTime.Now.ToLongDateString();
                this.dataBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.appdata);
                this.dataBindingSource.AddNew();
                txtserial.Text = "000000";



            }
            catch (Exception)
            {
                MessageBox.Show("Check serial #", "Message");
            }

        }
        private void Manage1_Load(object sender, EventArgs e)
        {
          
        }
        private void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Btndelete_Click(object sender, EventArgs e)
        {
            try
            {

                int rowIndex = dataDataGridView.CurrentCell.RowIndex;
                dataDataGridView.Rows.RemoveAt(rowIndex);
                this.dataBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.appdata);
                txtserial.Text = "000000";
            }
            catch (Exception)
            {
                MessageBox.Show("Are you sure to delete?", "Message");
            }
        }

        private void Manage_Load(object sender, EventArgs e)
        {
            this.dataTableAdapter.Fill(this.appdata.data);
            dataBindingSource.DataSource = this.appdata.data;
            this.dataBindingSource.AddNew();
        }

        private void DataBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.dataBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.appdata);

        }
    }
}
