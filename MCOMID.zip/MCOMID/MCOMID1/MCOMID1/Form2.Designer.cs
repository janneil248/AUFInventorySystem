﻿namespace MCOMID1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbluser = new System.Windows.Forms.Label();
            this.lbldate = new System.Windows.Forms.Label();
            this.lbltime = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btnchange = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.grad3 = new MCOMID1.Grad();
            this.manage1 = new MCOMID1.Manage();
            this.datacDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datacBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.appac = new MCOMID1.appac();
            this.dataDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.appdata = new MCOMID1.appdata();
            this.databrDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.databrBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.appbr = new MCOMID1.appbr();
            this.grad2 = new MCOMID1.Grad();
            this.grad1 = new MCOMID1.Grad();
            this.btnLogs = new System.Windows.Forms.Button();
            this.SidePanel = new System.Windows.Forms.Panel();
            this.btnAccounts = new System.Windows.Forms.Button();
            this.btnService = new System.Windows.Forms.Button();
            this.btnInventory = new System.Windows.Forms.Button();
            this.btnManage = new System.Windows.Forms.Button();
            this.dataTableAdapter = new MCOMID1.appdataTableAdapters.dataTableAdapter();
            this.tableAdapterManager = new MCOMID1.appdataTableAdapters.TableAdapterManager();
            this.databrTableAdapter = new MCOMID1.appbrTableAdapters.databrTableAdapter();
            this.tableAdapterManager1 = new MCOMID1.appbrTableAdapters.TableAdapterManager();
            this.datacTableAdapter = new MCOMID1.appacTableAdapters.datacTableAdapter();
            this.tableAdapterManager2 = new MCOMID1.appacTableAdapters.TableAdapterManager();
            this.service1 = new MCOMID1.Service();
            this.inventory1 = new MCOMID1.Inventory();
            this.account1 = new MCOMID1.Account();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.grad3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datacDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datacBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appac)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appdata)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databrDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databrBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appbr)).BeginInit();
            this.grad1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(13)))), ((int)(((byte)(13)))));
            this.panel1.Location = new System.Drawing.Point(184, 127);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(817, 11);
            this.panel1.TabIndex = 4;
            // 
            // lbluser
            // 
            this.lbluser.AutoSize = true;
            this.lbluser.Font = new System.Drawing.Font("Century Gothic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbluser.Location = new System.Drawing.Point(324, 30);
            this.lbluser.Name = "lbluser";
            this.lbluser.Size = new System.Drawing.Size(23, 16);
            this.lbluser.TabIndex = 5;
            this.lbluser.Text = "---";
            // 
            // lbldate
            // 
            this.lbldate.AutoSize = true;
            this.lbldate.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldate.Location = new System.Drawing.Point(835, 90);
            this.lbldate.Name = "lbldate";
            this.lbldate.Size = new System.Drawing.Size(35, 16);
            this.lbldate.TabIndex = 6;
            this.lbldate.Text = "Date";
            // 
            // lbltime
            // 
            this.lbltime.AutoSize = true;
            this.lbltime.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltime.Location = new System.Drawing.Point(837, 108);
            this.lbltime.Name = "lbltime";
            this.lbltime.Size = new System.Drawing.Size(32, 16);
            this.lbltime.TabIndex = 7;
            this.lbltime.Text = "Time";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick_1);
            // 
            // btnchange
            // 
            this.btnchange.FlatAppearance.BorderSize = 0;
            this.btnchange.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnchange.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnchange.ForeColor = System.Drawing.Color.Black;
            this.btnchange.Image = global::MCOMID1.Properties.Resources.change_30px;
            this.btnchange.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnchange.Location = new System.Drawing.Point(900, 10);
            this.btnchange.Name = "btnchange";
            this.btnchange.Size = new System.Drawing.Size(44, 47);
            this.btnchange.TabIndex = 9;
            this.btnchange.UseVisualStyleBackColor = true;
            this.btnchange.Click += new System.EventHandler(this.Btnchange_Click);
            // 
            // btnExit
            // 
            this.btnExit.FlatAppearance.BorderSize = 0;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.Black;
            this.btnExit.Image = global::MCOMID1.Properties.Resources.exit_30px;
            this.btnExit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExit.Location = new System.Drawing.Point(950, 10);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(44, 47);
            this.btnExit.TabIndex = 8;
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::MCOMID1.Properties.Resources.ccsccs;
            this.pictureBox1.Location = new System.Drawing.Point(184, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(124, 117);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // grad3
            // 
            this.grad3.Angle = 0F;
            this.grad3.BottomColor = System.Drawing.Color.Empty;
            this.grad3.Controls.Add(this.account1);
            this.grad3.Controls.Add(this.inventory1);
            this.grad3.Controls.Add(this.service1);
            this.grad3.Controls.Add(this.manage1);
            this.grad3.Controls.Add(this.datacDataGridView);
            this.grad3.Controls.Add(this.dataDataGridView);
            this.grad3.Controls.Add(this.databrDataGridView);
            this.grad3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.grad3.Location = new System.Drawing.Point(184, 138);
            this.grad3.Name = "grad3";
            this.grad3.Size = new System.Drawing.Size(817, 530);
            this.grad3.TabIndex = 3;
            this.grad3.TopColor = System.Drawing.Color.Empty;
            // 
            // manage1
            // 
            this.manage1.Location = new System.Drawing.Point(0, -1);
            this.manage1.Name = "manage1";
            this.manage1.Size = new System.Drawing.Size(851, 529);
            this.manage1.TabIndex = 13;
            // 
            // datacDataGridView
            // 
            this.datacDataGridView.AutoGenerateColumns = false;
            this.datacDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datacDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19});
            this.datacDataGridView.DataSource = this.datacBindingSource;
            this.datacDataGridView.Location = new System.Drawing.Point(357, 114);
            this.datacDataGridView.Name = "datacDataGridView";
            this.datacDataGridView.Size = new System.Drawing.Size(118, 99);
            this.datacDataGridView.TabIndex = 12;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "Account ID";
            this.dataGridViewTextBoxColumn15.HeaderText = "Account ID";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "First Name";
            this.dataGridViewTextBoxColumn16.HeaderText = "First Name";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "Last Name";
            this.dataGridViewTextBoxColumn17.HeaderText = "Last Name";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "UserName";
            this.dataGridViewTextBoxColumn18.HeaderText = "UserName";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "Password";
            this.dataGridViewTextBoxColumn19.HeaderText = "Password";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            // 
            // datacBindingSource
            // 
            this.datacBindingSource.DataMember = "datac";
            this.datacBindingSource.DataSource = this.appac;
            // 
            // appac
            // 
            this.appac.DataSetName = "appac";
            this.appac.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataDataGridView
            // 
            this.dataDataGridView.AutoGenerateColumns = false;
            this.dataDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.dataDataGridView.DataSource = this.dataBindingSource;
            this.dataDataGridView.Location = new System.Drawing.Point(91, 110);
            this.dataDataGridView.Name = "dataDataGridView";
            this.dataDataGridView.Size = new System.Drawing.Size(92, 103);
            this.dataDataGridView.TabIndex = 11;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Serial";
            this.dataGridViewTextBoxColumn1.HeaderText = "Serial";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Item Name";
            this.dataGridViewTextBoxColumn2.HeaderText = "Item Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Brand";
            this.dataGridViewTextBoxColumn3.HeaderText = "Brand";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Category";
            this.dataGridViewTextBoxColumn4.HeaderText = "Category";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Remarks";
            this.dataGridViewTextBoxColumn5.HeaderText = "Remarks";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "User";
            this.dataGridViewTextBoxColumn6.HeaderText = "User";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Logs";
            this.dataGridViewTextBoxColumn7.HeaderText = "Logs";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataBindingSource
            // 
            this.dataBindingSource.DataMember = "data";
            this.dataBindingSource.DataSource = this.appdata;
            // 
            // appdata
            // 
            this.appdata.DataSetName = "appdata";
            this.appdata.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // databrDataGridView
            // 
            this.databrDataGridView.AutoGenerateColumns = false;
            this.databrDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.databrDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14});
            this.databrDataGridView.DataSource = this.databrBindingSource;
            this.databrDataGridView.Location = new System.Drawing.Point(231, 110);
            this.databrDataGridView.Name = "databrDataGridView";
            this.databrDataGridView.Size = new System.Drawing.Size(85, 87);
            this.databrDataGridView.TabIndex = 11;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "ID #";
            this.dataGridViewTextBoxColumn8.HeaderText = "ID #";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Full Name";
            this.dataGridViewTextBoxColumn9.HeaderText = "Full Name";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Type";
            this.dataGridViewTextBoxColumn10.HeaderText = "Type";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Item";
            this.dataGridViewTextBoxColumn11.HeaderText = "Item";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Remarks";
            this.dataGridViewTextBoxColumn12.HeaderText = "Remarks";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "User";
            this.dataGridViewTextBoxColumn13.HeaderText = "User";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "Logs";
            this.dataGridViewTextBoxColumn14.HeaderText = "Logs";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // databrBindingSource
            // 
            this.databrBindingSource.DataMember = "databr";
            this.databrBindingSource.DataSource = this.appbr;
            // 
            // appbr
            // 
            this.appbr.DataSetName = "appbr";
            this.appbr.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // grad2
            // 
            this.grad2.Angle = 0F;
            this.grad2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(13)))), ((int)(((byte)(13)))));
            this.grad2.BottomColor = System.Drawing.Color.Empty;
            this.grad2.Dock = System.Windows.Forms.DockStyle.Top;
            this.grad2.Location = new System.Drawing.Point(184, 0);
            this.grad2.Name = "grad2";
            this.grad2.Size = new System.Drawing.Size(817, 10);
            this.grad2.TabIndex = 1;
            this.grad2.TopColor = System.Drawing.Color.Empty;
            // 
            // grad1
            // 
            this.grad1.Angle = 0F;
            this.grad1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.grad1.BottomColor = System.Drawing.Color.Empty;
            this.grad1.Controls.Add(this.btnLogs);
            this.grad1.Controls.Add(this.SidePanel);
            this.grad1.Controls.Add(this.btnAccounts);
            this.grad1.Controls.Add(this.btnService);
            this.grad1.Controls.Add(this.btnInventory);
            this.grad1.Controls.Add(this.btnManage);
            this.grad1.Dock = System.Windows.Forms.DockStyle.Left;
            this.grad1.Location = new System.Drawing.Point(0, 0);
            this.grad1.Name = "grad1";
            this.grad1.Size = new System.Drawing.Size(184, 668);
            this.grad1.TabIndex = 0;
            this.grad1.TopColor = System.Drawing.Color.Empty;
            // 
            // btnLogs
            // 
            this.btnLogs.FlatAppearance.BorderSize = 0;
            this.btnLogs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogs.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogs.ForeColor = System.Drawing.Color.White;
            this.btnLogs.Image = global::MCOMID1.Properties.Resources.file_30px;
            this.btnLogs.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLogs.Location = new System.Drawing.Point(12, 417);
            this.btnLogs.Name = "btnLogs";
            this.btnLogs.Size = new System.Drawing.Size(169, 54);
            this.btnLogs.TabIndex = 7;
            this.btnLogs.Text = "   Logs";
            this.btnLogs.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnLogs.UseVisualStyleBackColor = true;
            // 
            // SidePanel
            // 
            this.SidePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(13)))), ((int)(((byte)(13)))));
            this.SidePanel.Location = new System.Drawing.Point(1, 138);
            this.SidePanel.Name = "SidePanel";
            this.SidePanel.Size = new System.Drawing.Size(10, 54);
            this.SidePanel.TabIndex = 3;
            // 
            // btnAccounts
            // 
            this.btnAccounts.FlatAppearance.BorderSize = 0;
            this.btnAccounts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAccounts.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAccounts.ForeColor = System.Drawing.Color.White;
            this.btnAccounts.Image = global::MCOMID1.Properties.Resources.administrator_30px;
            this.btnAccounts.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAccounts.Location = new System.Drawing.Point(12, 347);
            this.btnAccounts.Name = "btnAccounts";
            this.btnAccounts.Size = new System.Drawing.Size(169, 54);
            this.btnAccounts.TabIndex = 6;
            this.btnAccounts.Text = "   Acccounts";
            this.btnAccounts.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAccounts.UseVisualStyleBackColor = true;
            this.btnAccounts.Click += new System.EventHandler(this.BtnAccounts_Click);
            // 
            // btnService
            // 
            this.btnService.FlatAppearance.BorderSize = 0;
            this.btnService.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnService.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnService.ForeColor = System.Drawing.Color.White;
            this.btnService.Image = global::MCOMID1.Properties.Resources.sorting_arrows_horizontal_filled_30px;
            this.btnService.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnService.Location = new System.Drawing.Point(12, 202);
            this.btnService.Name = "btnService";
            this.btnService.Size = new System.Drawing.Size(169, 54);
            this.btnService.TabIndex = 5;
            this.btnService.Text = "   Service";
            this.btnService.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnService.UseVisualStyleBackColor = true;
            this.btnService.Click += new System.EventHandler(this.BtnService_Click);
            // 
            // btnInventory
            // 
            this.btnInventory.FlatAppearance.BorderSize = 0;
            this.btnInventory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInventory.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInventory.ForeColor = System.Drawing.Color.White;
            this.btnInventory.Image = global::MCOMID1.Properties.Resources.cardboard_box_filled_30px;
            this.btnInventory.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnInventory.Location = new System.Drawing.Point(15, 272);
            this.btnInventory.Name = "btnInventory";
            this.btnInventory.Size = new System.Drawing.Size(169, 54);
            this.btnInventory.TabIndex = 4;
            this.btnInventory.Text = "   Inventory";
            this.btnInventory.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnInventory.UseVisualStyleBackColor = true;
            this.btnInventory.Click += new System.EventHandler(this.BtnInventory_Click);
            // 
            // btnManage
            // 
            this.btnManage.FlatAppearance.BorderSize = 0;
            this.btnManage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManage.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManage.ForeColor = System.Drawing.Color.White;
            this.btnManage.Image = global::MCOMID1.Properties.Resources.todo_list_32px;
            this.btnManage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnManage.Location = new System.Drawing.Point(12, 138);
            this.btnManage.Name = "btnManage";
            this.btnManage.Size = new System.Drawing.Size(169, 54);
            this.btnManage.TabIndex = 3;
            this.btnManage.Text = "   Manage";
            this.btnManage.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnManage.UseVisualStyleBackColor = true;
            this.btnManage.Click += new System.EventHandler(this.BtnManage_Click);
            // 
            // dataTableAdapter
            // 
            this.dataTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.dataTableAdapter = this.dataTableAdapter;
            this.tableAdapterManager.UpdateOrder = MCOMID1.appdataTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // databrTableAdapter
            // 
            this.databrTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.databrTableAdapter = this.databrTableAdapter;
            this.tableAdapterManager1.UpdateOrder = MCOMID1.appbrTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // datacTableAdapter
            // 
            this.datacTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager2
            // 
            this.tableAdapterManager2.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager2.datacTableAdapter = this.datacTableAdapter;
            this.tableAdapterManager2.UpdateOrder = MCOMID1.appacTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // service1
            // 
            this.service1.Location = new System.Drawing.Point(-3, -1);
            this.service1.Name = "service1";
            this.service1.Size = new System.Drawing.Size(851, 618);
            this.service1.TabIndex = 14;
            // 
            // inventory1
            // 
            this.inventory1.Location = new System.Drawing.Point(-4, -4);
            this.inventory1.Name = "inventory1";
            this.inventory1.Size = new System.Drawing.Size(852, 588);
            this.inventory1.TabIndex = 15;
            // 
            // account1
            // 
            this.account1.Location = new System.Drawing.Point(-2, -2);
            this.account1.Name = "account1";
            this.account1.Size = new System.Drawing.Size(852, 596);
            this.account1.TabIndex = 16;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(235)))), ((int)(((byte)(240)))));
            this.ClientSize = new System.Drawing.Size(1001, 668);
            this.Controls.Add(this.btnchange);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lbltime);
            this.Controls.Add(this.lbldate);
            this.Controls.Add(this.lbluser);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.grad3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.grad2);
            this.Controls.Add(this.grad1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.grad3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datacDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datacBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appac)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appdata)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databrDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databrBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appbr)).EndInit();
            this.grad1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Grad grad1;
        private Grad grad2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnManage;
        private System.Windows.Forms.Button btnAccounts;
        private System.Windows.Forms.Button btnService;
        private System.Windows.Forms.Button btnInventory;
        private System.Windows.Forms.Panel SidePanel;
        private Grad grad3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbluser;
        private System.Windows.Forms.Button btnLogs;
        private System.Windows.Forms.Label lbldate;
        private System.Windows.Forms.Label lbltime;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnchange;
        private appdata appdata;
        private System.Windows.Forms.BindingSource dataBindingSource;
        private appdataTableAdapters.dataTableAdapter dataTableAdapter;
        private appdataTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView dataDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private appbr appbr;
        private System.Windows.Forms.BindingSource databrBindingSource;
        private appbrTableAdapters.databrTableAdapter databrTableAdapter;
        private appbrTableAdapters.TableAdapterManager tableAdapterManager1;
        private System.Windows.Forms.DataGridView databrDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private appac appac;
        private System.Windows.Forms.BindingSource datacBindingSource;
        private appacTableAdapters.datacTableAdapter datacTableAdapter;
        private appacTableAdapters.TableAdapterManager tableAdapterManager2;
        private System.Windows.Forms.DataGridView datacDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private Manage manage1;
        private Inventory inventory1;
        private Service service1;
        private Account account1;
    }
}