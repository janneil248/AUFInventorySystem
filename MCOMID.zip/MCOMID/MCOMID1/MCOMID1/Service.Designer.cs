﻿namespace MCOMID1
{
    partial class Service
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.txtremarks = new System.Windows.Forms.TextBox();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnBorrow = new System.Windows.Forms.Button();
            this.cmbcat = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtitemserial = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtid = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.appbr = new MCOMID1.appbr();
            this.databrBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.databrTableAdapter = new MCOMID1.appbrTableAdapters.databrTableAdapter();
            this.tableAdapterManager = new MCOMID1.appbrTableAdapters.TableAdapterManager();
            this.databrDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lbldate = new System.Windows.Forms.Label();
            this.lbluser = new System.Windows.Forms.Label();
            this.lblremark = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.appbr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databrBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databrDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.panel1.Controls.Add(this.lblremark);
            this.panel1.Controls.Add(this.lbldate);
            this.panel1.Controls.Add(this.lbluser);
            this.panel1.Controls.Add(this.databrDataGridView);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtremarks);
            this.panel1.Controls.Add(this.btnReturn);
            this.panel1.Controls.Add(this.btnBorrow);
            this.panel1.Controls.Add(this.cmbcat);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtitemserial);
            this.panel1.Controls.Add(this.txtname);
            this.panel1.Controls.Add(this.txtid);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(2, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(848, 590);
            this.panel1.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(69, 194);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 19);
            this.label3.TabIndex = 14;
            this.label3.Text = "Remarks";
            // 
            // txtremarks
            // 
            this.txtremarks.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.txtremarks.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtremarks.Location = new System.Drawing.Point(206, 190);
            this.txtremarks.Name = "txtremarks";
            this.txtremarks.Size = new System.Drawing.Size(207, 27);
            this.txtremarks.TabIndex = 13;
            // 
            // btnReturn
            // 
            this.btnReturn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnReturn.FlatAppearance.BorderSize = 0;
            this.btnReturn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.Image = global::MCOMID1.Properties.Resources.return_purchase_30px;
            this.btnReturn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReturn.Location = new System.Drawing.Point(502, 95);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(148, 37);
            this.btnReturn.TabIndex = 12;
            this.btnReturn.Text = "     Return";
            this.btnReturn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.BtnReturn_Click);
            // 
            // btnBorrow
            // 
            this.btnBorrow.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnBorrow.FlatAppearance.BorderSize = 0;
            this.btnBorrow.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBorrow.Image = global::MCOMID1.Properties.Resources.add_shopping_cart_30px;
            this.btnBorrow.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBorrow.Location = new System.Drawing.Point(502, 31);
            this.btnBorrow.Name = "btnBorrow";
            this.btnBorrow.Size = new System.Drawing.Size(148, 37);
            this.btnBorrow.TabIndex = 10;
            this.btnBorrow.Text = "     Borrow";
            this.btnBorrow.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnBorrow.UseVisualStyleBackColor = false;
            this.btnBorrow.Click += new System.EventHandler(this.BtnBorrow_Click);
            // 
            // cmbcat
            // 
            this.cmbcat.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.cmbcat.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.databrBindingSource, "Type", true));
            this.cmbcat.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbcat.FormattingEnabled = true;
            this.cmbcat.Items.AddRange(new object[] {
            "FACULTY",
            "BSCS",
            "BSIT",
            "BSCS"});
            this.cmbcat.Location = new System.Drawing.Point(206, 106);
            this.cmbcat.Name = "cmbcat";
            this.cmbcat.Size = new System.Drawing.Size(207, 29);
            this.cmbcat.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(69, 110);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 19);
            this.label5.TabIndex = 8;
            this.label5.Text = "Occupation";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(69, 152);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 19);
            this.label4.TabIndex = 7;
            this.label4.Text = "Item Serial #";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(68, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 19);
            this.label2.TabIndex = 5;
            this.label2.Text = "Name";
            // 
            // txtitemserial
            // 
            this.txtitemserial.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.txtitemserial.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.databrBindingSource, "Item", true));
            this.txtitemserial.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtitemserial.Location = new System.Drawing.Point(206, 148);
            this.txtitemserial.Name = "txtitemserial";
            this.txtitemserial.Size = new System.Drawing.Size(207, 27);
            this.txtitemserial.TabIndex = 4;
            // 
            // txtname
            // 
            this.txtname.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.txtname.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.databrBindingSource, "Full Name", true));
            this.txtname.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.Location = new System.Drawing.Point(206, 67);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(207, 27);
            this.txtname.TabIndex = 2;
            // 
            // txtid
            // 
            this.txtid.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.txtid.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.databrBindingSource, "ID #", true));
            this.txtid.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtid.Location = new System.Drawing.Point(206, 27);
            this.txtid.Name = "txtid";
            this.txtid.Size = new System.Drawing.Size(207, 27);
            this.txtid.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(69, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID #";
            // 
            // appbr
            // 
            this.appbr.DataSetName = "appbr";
            this.appbr.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // databrBindingSource
            // 
            this.databrBindingSource.DataMember = "databr";
            this.databrBindingSource.DataSource = this.appbr;
            // 
            // databrTableAdapter
            // 
            this.databrTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.databrTableAdapter = this.databrTableAdapter;
            this.tableAdapterManager.UpdateOrder = MCOMID1.appbrTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // databrDataGridView
            // 
            this.databrDataGridView.AutoGenerateColumns = false;
            this.databrDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.databrDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.databrDataGridView.DataSource = this.databrBindingSource;
            this.databrDataGridView.Location = new System.Drawing.Point(72, 277);
            this.databrDataGridView.Name = "databrDataGridView";
            this.databrDataGridView.Size = new System.Drawing.Size(694, 220);
            this.databrDataGridView.TabIndex = 14;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ID #";
            this.dataGridViewTextBoxColumn1.HeaderText = "ID #";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Full Name";
            this.dataGridViewTextBoxColumn2.HeaderText = "Full Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Type";
            this.dataGridViewTextBoxColumn3.HeaderText = "Type";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Item";
            this.dataGridViewTextBoxColumn4.HeaderText = "Item";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Remarks";
            this.dataGridViewTextBoxColumn5.HeaderText = "Remarks";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "User";
            this.dataGridViewTextBoxColumn6.HeaderText = "User";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Logs";
            this.dataGridViewTextBoxColumn7.HeaderText = "Logs";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // lbldate
            // 
            this.lbldate.AutoSize = true;
            this.lbldate.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.databrBindingSource, "Logs", true));
            this.lbldate.Location = new System.Drawing.Point(766, 561);
            this.lbldate.Name = "lbldate";
            this.lbldate.Size = new System.Drawing.Size(35, 13);
            this.lbldate.TabIndex = 16;
            this.lbldate.Text = "label7";
            // 
            // lbluser
            // 
            this.lbluser.AutoSize = true;
            this.lbluser.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.databrBindingSource, "User", true));
            this.lbluser.Location = new System.Drawing.Point(674, 562);
            this.lbluser.Name = "lbluser";
            this.lbluser.Size = new System.Drawing.Size(35, 13);
            this.lbluser.TabIndex = 15;
            this.lbluser.Text = "label6";
            // 
            // lblremark
            // 
            this.lblremark.AutoSize = true;
            this.lblremark.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.databrBindingSource, "Remarks", true));
            this.lblremark.Location = new System.Drawing.Point(596, 561);
            this.lblremark.Name = "lblremark";
            this.lblremark.Size = new System.Drawing.Size(35, 13);
            this.lblremark.TabIndex = 17;
            this.lblremark.Text = "label6";
            // 
            // Service
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Name = "Service";
            this.Size = new System.Drawing.Size(851, 618);
            this.Load += new System.EventHandler(this.Service_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.appbr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databrBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databrDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnBorrow;
        private System.Windows.Forms.ComboBox cmbcat;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtitemserial;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtremarks;
        private appbr appbr;
        private System.Windows.Forms.BindingSource databrBindingSource;
        private appbrTableAdapters.databrTableAdapter databrTableAdapter;
        private appbrTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView databrDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.Label lblremark;
        private System.Windows.Forms.Label lbldate;
        private System.Windows.Forms.Label lbluser;
    }
}
