﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MCOMID1
{
    public partial class Service : UserControl
    {
        public Service()
        {
            InitializeComponent();
        }

        private void BtnBorrow_Click(object sender, EventArgs e)
        {
            try
            {

                lbluser.Text = "JP1";
                lbldate.Text = DateTime.Now.ToLongDateString();
                lblremark.Text = "Borrow : " + txtremarks.Text;
                this.databrBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.appbr);
                this.databrBindingSource.AddNew();
                txtid.Text = "000000";



            }
            catch (Exception)
            {
                MessageBox.Show("Check serial #", "Message");
            }
        }
        private void Service1_Load(object sender, EventArgs e)
        {
          

        }

        private void BtnReturn_Click(object sender, EventArgs e)
        {
            try
            {

                lbluser.Text = "JP1";
                lbldate.Text = DateTime.Now.ToLongDateString();
                lblremark.Text = "Return : " + txtremarks.Text;
                this.databrBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.appbr);
                this.databrBindingSource.AddNew();
                txtid.Text = "000000";



            }
            catch (Exception)
            {
                MessageBox.Show("Check serial #", "Message");
            }
        }

        private void DatabrBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.databrBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.appbr);

        }

        private void Service_Load(object sender, EventArgs e)
        {
            this.databrTableAdapter.Fill(this.appbr.databr);
            databrBindingSource.DataSource = this.appbr.databr;
            this.databrBindingSource.AddNew();
        }
    }
}
