﻿namespace MCOMID1
{
    partial class Inventory
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Inventory));
            this.panel1 = new System.Windows.Forms.Panel();
            this.Tab1 = new System.Windows.Forms.TabControl();
            this.tabonhand = new System.Windows.Forms.TabPage();
            this.tabborrowed = new System.Windows.Forms.TabPage();
            this.cmbfindcat = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtfindserial = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.appdata = new MCOMID1.appdata();
            this.dataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataTableAdapter = new MCOMID1.appdataTableAdapters.dataTableAdapter();
            this.tableAdapterManager = new MCOMID1.appdataTableAdapters.TableAdapterManager();
            this.dataDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.appbr = new MCOMID1.appbr();
            this.databrBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.databrTableAdapter = new MCOMID1.appbrTableAdapters.databrTableAdapter();
            this.tableAdapterManager1 = new MCOMID1.appbrTableAdapters.TableAdapterManager();
            this.databrDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            this.Tab1.SuspendLayout();
            this.tabonhand.SuspendLayout();
            this.tabborrowed.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.appdata)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appbr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databrBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databrDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.panel1.Controls.Add(this.Tab1);
            this.panel1.Controls.Add(this.cmbfindcat);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.txtfindserial);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(846, 561);
            this.panel1.TabIndex = 2;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel1_Paint);
            // 
            // Tab1
            // 
            this.Tab1.Controls.Add(this.tabonhand);
            this.Tab1.Controls.Add(this.tabborrowed);
            this.Tab1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tab1.ImageList = this.imageList1;
            this.Tab1.Location = new System.Drawing.Point(54, 118);
            this.Tab1.Name = "Tab1";
            this.Tab1.SelectedIndex = 0;
            this.Tab1.Size = new System.Drawing.Size(714, 331);
            this.Tab1.TabIndex = 10;
            // 
            // tabonhand
            // 
            this.tabonhand.AutoScroll = true;
            this.tabonhand.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.tabonhand.Controls.Add(this.dataDataGridView);
            this.tabonhand.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabonhand.ImageIndex = 0;
            this.tabonhand.Location = new System.Drawing.Point(4, 37);
            this.tabonhand.Name = "tabonhand";
            this.tabonhand.Padding = new System.Windows.Forms.Padding(3);
            this.tabonhand.Size = new System.Drawing.Size(706, 290);
            this.tabonhand.TabIndex = 0;
            this.tabonhand.Text = "Inventory";
            // 
            // tabborrowed
            // 
            this.tabborrowed.AutoScroll = true;
            this.tabborrowed.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.tabborrowed.Controls.Add(this.databrDataGridView);
            this.tabborrowed.ImageIndex = 1;
            this.tabborrowed.Location = new System.Drawing.Point(4, 37);
            this.tabborrowed.Name = "tabborrowed";
            this.tabborrowed.Padding = new System.Windows.Forms.Padding(3);
            this.tabborrowed.Size = new System.Drawing.Size(706, 290);
            this.tabborrowed.TabIndex = 1;
            this.tabborrowed.Text = "Service";
            // 
            // cmbfindcat
            // 
            this.cmbfindcat.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.cmbfindcat.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbfindcat.FormattingEnabled = true;
            this.cmbfindcat.Items.AddRange(new object[] {
            "Computer",
            "Laptop",
            "Projector",
            "Extension",
            "Tablet"});
            this.cmbfindcat.Location = new System.Drawing.Point(207, 63);
            this.cmbfindcat.Name = "cmbfindcat";
            this.cmbfindcat.Size = new System.Drawing.Size(207, 29);
            this.cmbfindcat.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(70, 67);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(112, 19);
            this.label5.TabIndex = 8;
            this.label5.Text = "Sort Category";
            // 
            // txtfindserial
            // 
            this.txtfindserial.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.txtfindserial.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfindserial.Location = new System.Drawing.Point(207, 27);
            this.txtfindserial.Name = "txtfindserial";
            this.txtfindserial.Size = new System.Drawing.Size(207, 27);
            this.txtfindserial.TabIndex = 1;
            this.txtfindserial.TextChanged += new System.EventHandler(this.Txtfindserial_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(70, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Find Serial #";
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "cardboard_box_filled_30px.png");
            this.imageList1.Images.SetKeyName(1, "sorting_arrows_horizontal_filled_30px.png");
            // 
            // appdata
            // 
            this.appdata.DataSetName = "appdata";
            this.appdata.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataBindingSource
            // 
            this.dataBindingSource.DataMember = "data";
            this.dataBindingSource.DataSource = this.appdata;
            // 
            // dataTableAdapter
            // 
            this.dataTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.dataTableAdapter = this.dataTableAdapter;
            this.tableAdapterManager.UpdateOrder = MCOMID1.appdataTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // dataDataGridView
            // 
            this.dataDataGridView.AutoGenerateColumns = false;
            this.dataDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.dataDataGridView.DataSource = this.dataBindingSource;
            this.dataDataGridView.Location = new System.Drawing.Point(0, 0);
            this.dataDataGridView.Name = "dataDataGridView";
            this.dataDataGridView.Size = new System.Drawing.Size(710, 290);
            this.dataDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Serial";
            this.dataGridViewTextBoxColumn1.HeaderText = "Serial";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Item Name";
            this.dataGridViewTextBoxColumn2.HeaderText = "Item Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Brand";
            this.dataGridViewTextBoxColumn3.HeaderText = "Brand";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Category";
            this.dataGridViewTextBoxColumn4.HeaderText = "Category";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Remarks";
            this.dataGridViewTextBoxColumn5.HeaderText = "Remarks";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "User";
            this.dataGridViewTextBoxColumn6.HeaderText = "User";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Logs";
            this.dataGridViewTextBoxColumn7.HeaderText = "Logs";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // appbr
            // 
            this.appbr.DataSetName = "appbr";
            this.appbr.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // databrBindingSource
            // 
            this.databrBindingSource.DataMember = "databr";
            this.databrBindingSource.DataSource = this.appbr;
            // 
            // databrTableAdapter
            // 
            this.databrTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.databrTableAdapter = this.databrTableAdapter;
            this.tableAdapterManager1.UpdateOrder = MCOMID1.appbrTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // databrDataGridView
            // 
            this.databrDataGridView.AutoGenerateColumns = false;
            this.databrDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.databrDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14});
            this.databrDataGridView.DataSource = this.databrBindingSource;
            this.databrDataGridView.Location = new System.Drawing.Point(-4, 0);
            this.databrDataGridView.Name = "databrDataGridView";
            this.databrDataGridView.Size = new System.Drawing.Size(710, 294);
            this.databrDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "ID #";
            this.dataGridViewTextBoxColumn8.HeaderText = "ID #";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Full Name";
            this.dataGridViewTextBoxColumn9.HeaderText = "Full Name";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Type";
            this.dataGridViewTextBoxColumn10.HeaderText = "Type";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Item";
            this.dataGridViewTextBoxColumn11.HeaderText = "Item";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Remarks";
            this.dataGridViewTextBoxColumn12.HeaderText = "Remarks";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "User";
            this.dataGridViewTextBoxColumn13.HeaderText = "User";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "Logs";
            this.dataGridViewTextBoxColumn14.HeaderText = "Logs";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // Inventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Name = "Inventory";
            this.Size = new System.Drawing.Size(852, 588);
            this.Load += new System.EventHandler(this.Inventory_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.Tab1.ResumeLayout(false);
            this.tabonhand.ResumeLayout(false);
            this.tabborrowed.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.appdata)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appbr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databrBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databrDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cmbfindcat;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtfindserial;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl Tab1;
        private System.Windows.Forms.TabPage tabonhand;
        private System.Windows.Forms.TabPage tabborrowed;
        private System.Windows.Forms.ImageList imageList1;
        private appdata appdata;
        private System.Windows.Forms.BindingSource dataBindingSource;
        private appdataTableAdapters.dataTableAdapter dataTableAdapter;
        private appdataTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView dataDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridView databrDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.BindingSource databrBindingSource;
        private appbr appbr;
        private appbrTableAdapters.databrTableAdapter databrTableAdapter;
        private appbrTableAdapters.TableAdapterManager tableAdapterManager1;
    }
}
